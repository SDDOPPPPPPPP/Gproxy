package main

import (
	"errors"
	"fmt"
	"log"
	"sync"

	"github.com/sandertv/gophertunnel/minecraft"
	"github.com/sandertv/gophertunnel/minecraft/auth"
	"github.com/sandertv/gophertunnel/minecraft/protocol/packet"
	"golang.org/x/oauth2"
)

const (
	localAddress  = "0.0.0.0:19132"
	remoteAddress = "127.0.0.1:19133"
)

func main() {
	token, err := auth.RequestLiveToken()
	if err != nil {
		log.Fatalf("RequestLiveToken: %v", err)
	}
	src := auth.RefreshTokenSource(token)

	statusProvider, err := minecraft.NewForeignStatusProvider(remoteAddress)
	if err != nil {
		log.Fatalf("NewForeignStatusProvider: %v", err)
	}

	listener, err := minecraft.ListenConfig{
		StatusProvider: statusProvider,
	}.Listen("raknet", localAddress)
	if err != nil {
		log.Fatalf("Listen: %v", err)
	}
	defer listener.Close()

	log.Printf("proxy listening on %s -> %s", localAddress, remoteAddress)

	for {
		c, err := listener.Accept()
		if err != nil {
			log.Fatalf("Accept: %v", err)
		}

		conn, ok := c.(*minecraft.Conn)
		if !ok {
			log.Printf("unexpected connection type: %T", c)
			continue
		}

		go handleConn(conn, listener, src)
	}
}

func handleConn(conn *minecraft.Conn, listener *minecraft.Listener, src oauth2.TokenSource) {
	serverConn, err := minecraft.Dialer{
		TokenSource: src,
		ClientData:  conn.ClientData(),
	}.Dial("raknet", remoteAddress)
	if err != nil {
		log.Printf("Dial remote: %v", err)
		_ = listener.Disconnect(conn, "proxy connect failed")
		return
	}

	var wg sync.WaitGroup
	wg.Add(2)

	go func() {
		defer wg.Done()
		if err := conn.StartGame(serverConn.GameData()); err != nil {
			log.Printf("StartGame: %v", err)
		}
	}()

	go func() {
		defer wg.Done()
		if err := serverConn.DoSpawn(); err != nil {
			log.Printf("DoSpawn: %v", err)
		}
	}()

	wg.Wait()

	go func() {
		defer serverConn.Close()
		defer listener.Disconnect(conn, "connection lost")

		for {
			pk, err := conn.ReadPacket()
			if err != nil {
				return
			}

			logPacket("C→S", pk)

			if err := serverConn.WritePacket(pk); err != nil {
				var disc minecraft.DisconnectError
				if errors.As(err, &disc) {
					_ = listener.Disconnect(conn, disc.Error())
				}
				return
			}
		}
	}()

	go func() {
		defer conn.Close()
		defer listener.Disconnect(conn, "connection lost")

		for {
			pk, err := serverConn.ReadPacket()
			if err != nil {
				var disc minecraft.DisconnectError
				if errors.As(err, &disc) {
					_ = listener.Disconnect(conn, disc.Error())
				}
				return
			}

			logPacket("S→C", pk)

			if err := conn.WritePacket(pk); err != nil {
				return
			}
		}
	}()
}

func logPacket(dir string, pk packet.Packet) {
	fmt.Printf("[%s] %T\n", dir, pk)
}